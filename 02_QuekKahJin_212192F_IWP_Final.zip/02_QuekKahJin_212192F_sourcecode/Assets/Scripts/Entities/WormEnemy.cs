using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WormEnemy : MonoBehaviour
{
    // 3 Segment Worm
    // Collider for ground in the head
    // 
}
