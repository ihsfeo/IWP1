using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    Vector3 Direction;
    Vector3 Velocity;

    int Pierce;

    int Damage;
    // Weapons Type of Damage

    List<GameObject> HitTarget;

    // Bounce (Wtf is Bounce??????)

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
