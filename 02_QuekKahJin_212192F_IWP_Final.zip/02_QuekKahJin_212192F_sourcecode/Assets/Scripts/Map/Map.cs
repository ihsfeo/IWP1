using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map : MonoBehaviour
{
    public LinkedList<LinkedList<Room>> LLMap = new LinkedList<LinkedList<Room>>();
}
